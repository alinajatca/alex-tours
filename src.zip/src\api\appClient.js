import { db } from "@/lib/firebase";
import {
  collection,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  query,
  limit,
  orderBy,
} from "firebase/firestore";
 
const createEntity = (collectionName) => ({
  list: async (maxItems = 100) => {
    const q = query(collection(db, collectionName), limit(maxItems));
    const snapshot = await getDocs(q);
    return snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
  },
  create: async (data) => {
    const docRef = await addDoc(collection(db, collectionName), {
      ...data,
      created_date: new Date().toISOString(),
    });
    return { id: docRef.id, ...data };
  },
  update: async (id, data) => {
    await updateDoc(doc(db, collectionName, id), data);
    return { id, ...data };
  },
  delete: async (id) => {
    await deleteDoc(doc(db, collectionName, id));
    return { id };
  },
});
 
const createAnnouncementEntity = () => ({
  list: async (maxItems = 20) => {
    try {
      const q = query(
        collection(db, "announcements"),
        orderBy("created_date", "desc"),
        limit(maxItems)
      );
      const snapshot = await getDocs(q);
      return snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
    } catch {
      const q = query(collection(db, "announcements"), limit(maxItems));
      const snapshot = await getDocs(q);
      return snapshot.docs
        .map((d) => ({ id: d.id, ...d.data() }))
        .sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
    }
  },
  create: async (data) => {
    const docRef = await addDoc(collection(db, "announcements"), {
      ...data,
      created_date: new Date().toISOString(),
    });
    return { id: docRef.id, ...data };
  },
  update: async (id, data) => {
    await updateDoc(doc(db, "announcements", id), data);
    return { id, ...data };
  },
  delete: async (id) => {
    await deleteDoc(doc(db, "announcements", id));
    return { id };
  },
});
 
export const appClient = {
  entities: {
    Employee: createEntity("employees"),
    Attendance: createEntity("attendance"),
    AttendanceEvent: createEntity("attendance_events"),
    Task: createEntity("tasks"),
    Room: createEntity("rooms"),
    Message: createEntity("messages"),
    File: createEntity("files"),
    ProductivityLog: createEntity("productivity_logs"),
    CalendarEvent: createEntity("calendar_events"),
    Client: createEntity("clients"),
    Announcement: createAnnouncementEntity(),
    MoodVote: createEntity("mood_votes"),
    LeaveRequest: createEntity("leave_requests"),
  },
};